--
-- PostgreSQL database dump
--

\restrict cURIc3vrFNc9uLXGoBKjmqna44gtwgWUGrMExAx8CSNhcPlfxhPT9hIprRgcys0

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: researcher
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO researcher;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: researcher
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AssertionCriticality; Type: TYPE; Schema: public; Owner: researcher
--

CREATE TYPE public."AssertionCriticality" AS ENUM (
    'CRITICAL',
    'HIGH',
    'MEDIUM',
    'LOW'
);


ALTER TYPE public."AssertionCriticality" OWNER TO researcher;

--
-- Name: AssertionStatus; Type: TYPE; Schema: public; Owner: researcher
--

CREATE TYPE public."AssertionStatus" AS ENUM (
    'CLAIM',
    'EVIDENCE',
    'REJECTED'
);


ALTER TYPE public."AssertionStatus" OWNER TO researcher;

--
-- Name: CrawlStatus; Type: TYPE; Schema: public; Owner: researcher
--

CREATE TYPE public."CrawlStatus" AS ENUM (
    'IN_PROGRESS',
    'PAUSED',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE public."CrawlStatus" OWNER TO researcher;

--
-- Name: ExtractionStatus; Type: TYPE; Schema: public; Owner: researcher
--

CREATE TYPE public."ExtractionStatus" AS ENUM (
    'PENDING',
    'COMPLETED',
    'FAILED',
    'STALE'
);


ALTER TYPE public."ExtractionStatus" OWNER TO researcher;

--
-- Name: ResearchSessionStatus; Type: TYPE; Schema: public; Owner: researcher
--

CREATE TYPE public."ResearchSessionStatus" AS ENUM (
    'INITIALIZING',
    'PLANNING',
    'RESEARCHING',
    'PAUSED',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE public."ResearchSessionStatus" OWNER TO researcher;

--
-- Name: ResearchTaskStatus; Type: TYPE; Schema: public; Owner: researcher
--

CREATE TYPE public."ResearchTaskStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'FAILED',
    'CANCELLED',
    'PAUSED'
);


ALTER TYPE public."ResearchTaskStatus" OWNER TO researcher;

--
-- Name: ResearchWorkflow; Type: TYPE; Schema: public; Owner: researcher
--

CREATE TYPE public."ResearchWorkflow" AS ENUM (
    'DISCOVERY',
    'ANALYSIS'
);


ALTER TYPE public."ResearchWorkflow" OWNER TO researcher;

--
-- Name: SourceRelevance; Type: TYPE; Schema: public; Owner: researcher
--

CREATE TYPE public."SourceRelevance" AS ENUM (
    'DIRECT_EVIDENCE',
    'STRONG_SUPPORT',
    'PARTIAL_SUPPORT',
    'WEAK_SUPPORT',
    'NOT_RELEVANT',
    'MISLEADING'
);


ALTER TYPE public."SourceRelevance" OWNER TO researcher;

--
-- Name: SourceStatus; Type: TYPE; Schema: public; Owner: researcher
--

CREATE TYPE public."SourceStatus" AS ENUM (
    'PROPOSED',
    'VALIDATED',
    'REJECTED'
);


ALTER TYPE public."SourceStatus" OWNER TO researcher;

--
-- Name: SourceType; Type: TYPE; Schema: public; Owner: researcher
--

CREATE TYPE public."SourceType" AS ENUM (
    'BLOG',
    'GITHUB_LIST',
    'GITHUB_TRENDING',
    'GITHUB_REPO',
    'NEWSLETTER',
    'AGGREGATOR',
    'REDDIT',
    'X_ACCOUNT',
    'X_SEARCH',
    'FORUM',
    'NEWS',
    'ACADEMIC',
    'DEV_COMMUNITY'
);


ALTER TYPE public."SourceType" OWNER TO researcher;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO researcher;

--
-- Name: assertion_sources; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.assertion_sources (
    id text NOT NULL,
    quote text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "assertionId" text NOT NULL,
    "sourceId" text NOT NULL,
    annotation text,
    "gradedAt" timestamp(3) without time zone,
    "gradedBy" text,
    "relevanceGrade" public."SourceRelevance",
    "addedBy" text
);


ALTER TABLE public.assertion_sources OWNER TO researcher;

--
-- Name: assertions; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.assertions (
    id text NOT NULL,
    claim text NOT NULL,
    status public."AssertionStatus" DEFAULT 'CLAIM'::public."AssertionStatus" NOT NULL,
    category text,
    confidence double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "validatedAt" timestamp(3) without time zone,
    "validatedBy" text,
    "entityId" text NOT NULL,
    "citedInConclusion" boolean DEFAULT false NOT NULL,
    "conclusionContext" text,
    criticality public."AssertionCriticality" DEFAULT 'MEDIUM'::public."AssertionCriticality" NOT NULL,
    "rejectionReason" text,
    "supersededBy" text,
    "humanResponse" text,
    "partiallyValidated" boolean DEFAULT false NOT NULL,
    "validationNotes" jsonb,
    "evidenceScreenshots" text[],
    "evidenceChain" jsonb,
    "evidenceDescription" text,
    "evidenceScreenshotPath" text,
    "confidenceFactors" jsonb,
    "lastValidatedAt" timestamp(3) without time zone,
    "validationHistory" jsonb,
    "criticalityFactors" jsonb,
    "criticalityScore" double precision,
    "discoverySourceId" text,
    "firstDiscoveredAt" timestamp(3) without time zone,
    "mentionCount" integer DEFAULT 1 NOT NULL,
    "sourceSpread" integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.assertions OWNER TO researcher;

--
-- Name: discovery_crawls; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.discovery_crawls (
    id text NOT NULL,
    "projectId" text,
    "sourceIds" text[],
    "researchFocus" text,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "pausedAt" timestamp(3) without time zone,
    status public."CrawlStatus" DEFAULT 'IN_PROGRESS'::public."CrawlStatus" NOT NULL,
    "sourcesTotal" integer NOT NULL,
    "sourcesComplete" integer DEFAULT 0 NOT NULL,
    "sourcesFailed" integer DEFAULT 0 NOT NULL,
    "discoveriesFound" integer DEFAULT 0 NOT NULL,
    "entitiesCreated" integer DEFAULT 0 NOT NULL,
    "entitiesUpdated" integer DEFAULT 0 NOT NULL,
    "trendsDetected" integer DEFAULT 0 NOT NULL,
    checkpoint jsonb
);


ALTER TABLE public.discovery_crawls OWNER TO researcher;

--
-- Name: discovery_sources; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.discovery_sources (
    id text NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    "sourceType" public."SourceType" NOT NULL,
    category text NOT NULL,
    "crawlStrategy" text NOT NULL,
    "crawlFrequency" text NOT NULL,
    "crawlDepth" integer DEFAULT 1 NOT NULL,
    selectors jsonb,
    "feedUrl" text,
    "apiEndpoint" text,
    "lastCrawledAt" timestamp(3) without time zone,
    "lastSuccessAt" timestamp(3) without time zone,
    "lastError" text,
    "consecutiveErrors" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "discoveriesCount" integer DEFAULT 0 NOT NULL,
    "validatedCount" integer DEFAULT 0 NOT NULL,
    "hitRate" double precision,
    "avgNoveltyScore" double precision,
    description text,
    tags text[],
    priority integer DEFAULT 50 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.discovery_sources OWNER TO researcher;

--
-- Name: discovery_trends; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.discovery_trends (
    id text NOT NULL,
    "projectId" text,
    name text NOT NULL,
    description text,
    category text,
    "mentionCount" integer DEFAULT 0 NOT NULL,
    "entityCount" integer DEFAULT 0 NOT NULL,
    "sourceSpread" integer DEFAULT 0 NOT NULL,
    velocity double precision,
    "firstSeenAt" timestamp(3) without time zone NOT NULL,
    "lastSeenAt" timestamp(3) without time zone NOT NULL,
    "peakAt" timestamp(3) without time zone,
    "entityIds" text[],
    keywords text[],
    "trendScore" double precision,
    "emergingScore" double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.discovery_trends OWNER TO researcher;

--
-- Name: entities; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.entities (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "entityType" text,
    url text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "projectId" text NOT NULL,
    "logoFetchedAt" timestamp(3) without time zone,
    "logoFormat" text,
    "logoPath" text,
    "logoSourceUrl" text,
    "logoUrl" text,
    "logoVerified" boolean DEFAULT false NOT NULL,
    "logoSvgContent" text,
    "discoveryCategory" text,
    "domainId" text
);


ALTER TABLE public.entities OWNER TO researcher;

--
-- Name: extractions; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.extractions (
    id text NOT NULL,
    "schemaType" text NOT NULL,
    data jsonb NOT NULL,
    "rawQuotes" jsonb,
    status public."ExtractionStatus" DEFAULT 'COMPLETED'::public."ExtractionStatus" NOT NULL,
    confidence double precision,
    error text,
    "extractedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "entityId" text NOT NULL,
    "sourceId" text NOT NULL,
    "screenshotId" text,
    "assertionIds" text[]
);


ALTER TABLE public.extractions OWNER TO researcher;

--
-- Name: raw_discoveries; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.raw_discoveries (
    id text NOT NULL,
    "sourceId" text NOT NULL,
    "mentionedName" text NOT NULL,
    "briefDescription" text,
    "discoveryUrl" text NOT NULL,
    "contextSnippet" text,
    "extractedLinks" text[],
    "releaseVersion" text,
    "releaseDate" timestamp(3) without time zone,
    keywords text[],
    "discoveredAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "crawlSessionId" text NOT NULL,
    processed boolean DEFAULT false NOT NULL,
    "matchedEntityId" text,
    "createdEntityId" text,
    "noveltyScore" double precision,
    "relevanceScore" double precision
);


ALTER TABLE public.raw_discoveries OWNER TO researcher;

--
-- Name: reasoning; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.reasoning (
    id text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "assertionId" text NOT NULL
);


ALTER TABLE public.reasoning OWNER TO researcher;

--
-- Name: research_domains; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.research_domains (
    id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    "entityTypes" text[],
    "inclusionCriteria" text,
    "exclusionCriteria" text,
    "searchHints" text,
    "knownLeaders" text[],
    "relevantTopics" text[],
    "evaluationDimensions" jsonb,
    "lastDiscoveryAt" timestamp(3) without time zone,
    "entityCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text
);


ALTER TABLE public.research_domains OWNER TO researcher;

--
-- Name: research_logs; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.research_logs (
    id text NOT NULL,
    action text NOT NULL,
    details jsonb,
    "agentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.research_logs OWNER TO researcher;

--
-- Name: research_projects; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.research_projects (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "searchQuery" text,
    workflow public."ResearchWorkflow" DEFAULT 'DISCOVERY'::public."ResearchWorkflow" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.research_projects OWNER TO researcher;

--
-- Name: research_sessions; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.research_sessions (
    id text NOT NULL,
    "entityId" text NOT NULL,
    "projectId" text NOT NULL,
    "researcherName" text NOT NULL,
    status public."ResearchSessionStatus" DEFAULT 'INITIALIZING'::public."ResearchSessionStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "pausedAt" timestamp(3) without time zone,
    categories text[],
    mode text NOT NULL,
    config jsonb,
    "overallProgress" jsonb,
    "totalTasks" integer DEFAULT 0 NOT NULL,
    "completedTasks" integer DEFAULT 0 NOT NULL,
    "failedTasks" integer DEFAULT 0 NOT NULL,
    "totalAssertions" integer DEFAULT 0 NOT NULL,
    "totalScreenshots" integer DEFAULT 0 NOT NULL,
    "totalExtractions" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.research_sessions OWNER TO researcher;

--
-- Name: research_tasks; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.research_tasks (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    category text NOT NULL,
    status public."ResearchTaskStatus" DEFAULT 'PENDING'::public."ResearchTaskStatus" NOT NULL,
    "agentId" text,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    error text,
    progress jsonb,
    results jsonb
);


ALTER TABLE public.research_tasks OWNER TO researcher;

--
-- Name: screenshots; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.screenshots (
    id text NOT NULL,
    "filePath" text NOT NULL,
    url text NOT NULL,
    "fullPage" boolean DEFAULT true NOT NULL,
    width integer,
    height integer,
    "capturedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.screenshots OWNER TO researcher;

--
-- Name: sources; Type: TABLE; Schema: public; Owner: researcher
--

CREATE TABLE public.sources (
    id text NOT NULL,
    url text NOT NULL,
    title text,
    description text,
    "sourceType" text,
    status public."SourceStatus" DEFAULT 'PROPOSED'::public."SourceStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "validatedAt" timestamp(3) without time zone,
    "validatedBy" text,
    "contentHash" text,
    "isAccessible" boolean DEFAULT true NOT NULL,
    "lastFetchedAt" timestamp(3) without time zone,
    "lastStatusCode" integer
);


ALTER TABLE public.sources OWNER TO researcher;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
67e8bbc2-57ea-4043-8142-bffa010c073c	ea9a631717477c9416950c722768cfb5ff57dcbbad55891685795a9c84a4ae0b	2026-01-20 17:13:05.638896+00	20251224142901_init	\N	\N	2026-01-20 17:13:05.509908+00	1
44d065a7-a6cc-4fed-b052-65c8f6256845	6f37efd1e30909e73520739f90acc0424ae58b0cc28a069a58daf424196bd92f	2026-01-20 17:13:06.025988+00	20260116163937_add_discovery_category	\N	\N	2026-01-20 17:13:06.019866+00	1
e51e1384-816f-403f-8e59-6afcf6ea3beb	732fc994fde89b9924a1e45db8dcc4a942ec1022cdd8abda8f69ebf547bc60fb	2026-01-20 17:13:05.691956+00	20251226163659_add_extraction_models	\N	\N	2026-01-20 17:13:05.640891+00	1
5ad041b8-0b5f-4f48-9076-68b542e7c40e	b58393193785a7fc026d5c21a3ec45ef9b1808545dd8967c8a182edbf849ea51	2026-01-20 17:13:05.701379+00	20251230142648_add_logo_fields	\N	\N	2026-01-20 17:13:05.69413+00	1
88793de2-92fb-4add-9937-cb9f47cf46f0	8732a20b65b2cdf94fbe31b4091aef4db9f28587f4d5b07df0ab3806e387b6fc	2026-01-20 17:13:05.709461+00	20251230144635_add_logo_svg_content	\N	\N	2026-01-20 17:13:05.703404+00	1
23bb1c41-f21a-4e09-85d1-86f79ec0574a	f44d57d80611bb705421fb4875babb9995b4127c556cd99a51c28996d5126f2e	2026-01-20 17:13:06.071028+00	20260120145229_add_research_domains	\N	\N	2026-01-20 17:13:06.029228+00	1
bfe0ac3f-9068-4fc7-b483-33ebdedd20eb	af64f12cc956818ee23329dc83b5716066880f37dff039464a5a34da5010b9d8	2026-01-20 17:13:05.743893+00	20251231140927_add_criticality	\N	\N	2026-01-20 17:13:05.711552+00	1
2c020836-2e51-43ee-8b87-8be7e9d54a82	cc40a3e114d94805ec778ac188b2581ce9a3c7b3385e52acbec9f554026fd0d4	2026-01-20 17:13:05.754555+00	20260105144005_add_validation_dialogue	\N	\N	2026-01-20 17:13:05.74624+00	1
bb81b9bd-4fc8-4ad4-8c27-a13f04008c6e	5024728d7d17acf8870821bdfc9a4d3ca8b83c9044ab537c3202bc4bba8ee30b	2026-01-20 17:13:05.776267+00	20260106144602_add_evidence_screenshots	\N	\N	2026-01-20 17:13:05.756741+00	1
a2041228-9888-4edd-839c-e78837c02e7f	b4e3f7c07f6fa7b09ac2a1f5328c590bd8d27a0e2e9f856b4cbd88d85284ecbd	2026-01-20 17:13:05.792131+00	20260106181815_add_source_grading	\N	\N	2026-01-20 17:13:05.778877+00	1
4d9a0230-9bd2-4515-b514-7a1d66f14cfd	3a94548065fec8cf25003f66395c45586666095e1c46c7bcfa570a978c489edd	2026-01-20 17:13:05.808285+00	20260106182708_add_source_addedby	\N	\N	2026-01-20 17:13:05.794264+00	1
cb9cde1f-69af-4659-b084-0cd7a16ac215	ce9ebf3743c32ce1a9246c11402ea154c174a463924671a8600519603d319f7b	2026-01-20 17:13:05.816695+00	20260107181759_add_evidence_chain_fields	\N	\N	2026-01-20 17:13:05.810374+00	1
3286bab9-a931-4ac7-aca4-ba082def9b3a	d406c68ac7b0df316e92461aeee4fa623521e3e0f6fd6abdcb8ec37e11a1e2c3	2026-01-20 17:13:05.877651+00	20260108205506_add_research_sessions	\N	\N	2026-01-20 17:13:05.818837+00	1
bea029c4-e915-43f7-b3b0-e10039ec7240	c86a5589eed3bd327d9c8c2ec084398f52935487391965cb84601edf23acf5ae	2026-01-20 17:13:05.885374+00	20260109173449_add_confidence_tracking_fields	\N	\N	2026-01-20 17:13:05.879443+00	1
bcab75b7-292c-42e2-9303-0f4fc127b98c	b446324d9332f1fa4069c0d26c1c7c2b3e0a766fed5855e985473b0dc3676998	2026-01-20 17:13:06.016041+00	20260112183527_add_discovery_models	\N	\N	2026-01-20 17:13:05.887299+00	1
\.


--
-- Data for Name: assertion_sources; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.assertion_sources (id, quote, "createdAt", "assertionId", "sourceId", annotation, "gradedAt", "gradedBy", "relevanceGrade", "addedBy") FROM stdin;
\.


--
-- Data for Name: assertions; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.assertions (id, claim, status, category, confidence, "createdAt", "updatedAt", "validatedAt", "validatedBy", "entityId", "citedInConclusion", "conclusionContext", criticality, "rejectionReason", "supersededBy", "humanResponse", "partiallyValidated", "validationNotes", "evidenceScreenshots", "evidenceChain", "evidenceDescription", "evidenceScreenshotPath", "confidenceFactors", "lastValidatedAt", "validationHistory", "criticalityFactors", "criticalityScore", "discoverySourceId", "firstDiscoveredAt", "mentionCount", "sourceSpread") FROM stdin;
\.


--
-- Data for Name: discovery_crawls; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.discovery_crawls (id, "projectId", "sourceIds", "researchFocus", "startedAt", "completedAt", "pausedAt", status, "sourcesTotal", "sourcesComplete", "sourcesFailed", "discoveriesFound", "entitiesCreated", "entitiesUpdated", "trendsDetected", checkpoint) FROM stdin;
\.


--
-- Data for Name: discovery_sources; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.discovery_sources (id, name, url, "sourceType", category, "crawlStrategy", "crawlFrequency", "crawlDepth", selectors, "feedUrl", "apiEndpoint", "lastCrawledAt", "lastSuccessAt", "lastError", "consecutiveErrors", "isActive", "discoveriesCount", "validatedCount", "hitRate", "avgNoveltyScore", description, tags, priority, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: discovery_trends; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.discovery_trends (id, "projectId", name, description, category, "mentionCount", "entityCount", "sourceSpread", velocity, "firstSeenAt", "lastSeenAt", "peakAt", "entityIds", keywords, "trendScore", "emergingScore", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: entities; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.entities (id, name, description, "entityType", url, "createdAt", "updatedAt", "projectId", "logoFetchedAt", "logoFormat", "logoPath", "logoSourceUrl", "logoUrl", "logoVerified", "logoSvgContent", "discoveryCategory", "domainId") FROM stdin;
cmkmvucn6000074tu9jjh9wea	Datadog	Observability platform with Watchdog AI for anomaly detection without pre-configured thresholds	platform	https://www.datadoghq.com	2026-01-20 17:43:16.865	2026-01-20 17:43:16.865	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvuxyr0000cptupdif066l	Devin	Autonomous AI software engineer by Cognition AI that handles project planning, code generation, testing, and documentation	platform	https://devin.ai	2026-01-20 17:43:44.498	2026-01-20 17:43:44.498	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvuyt40000dwtu0oa0t8lx	Cursor	AI-native IDE rebuilt from VS Code with chat, edit, generate, and debug features using Claude and GPT models with full codebase context awareness	tool	https://cursor.com	2026-01-20 17:43:45.591	2026-01-20 17:43:45.591	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvv4fd0000grtuuxf08eca	Mabl	AI-powered test automation platform with agentic workflows acting like skilled human testers	tool	https://www.mabl.com	2026-01-20 17:43:52.872	2026-01-20 17:43:52.872	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvv5g00000ictuaepu82rp	Dynatrace	AI-powered observability with Davis AI for automated root cause analysis and predictive insights	platform	https://www.dynatrace.com	2026-01-20 17:43:54.186	2026-01-20 17:43:54.186	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvvp2d0000p7tun51tcoqp	OpenHands	Open-source platform acting as full-capability software developer with terminal, API, browser, and file management	platform	https://docs.all-hands.dev	2026-01-20 17:44:19.62	2026-01-20 17:44:19.62	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvvrol0000qrtut1zjo7fb	Windsurf	AI-powered IDE by Codeium featuring Cascade AI assistant with agentic workflows, multi-file editing, and instant live previews	tool	https://windsurf.com	2026-01-20 17:44:23.012	2026-01-20 17:44:23.012	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvvu2p0000shtueglgn100	Virtuoso QA	AI-powered no-code test automation for faster releases with self-maintaining test suites	platform	https://www.virtuoso.qa	2026-01-20 17:44:26.046	2026-01-20 17:44:26.046	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvvwym0000vhtuhkactypx	Braintrust	Best overall AI observability platform for monitoring AI agents with embedded clustering	platform	https://www.braintrust.dev	2026-01-20 17:44:29.853	2026-01-20 17:44:29.853	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvwh63000014tuu8d8p7tg	Bolt.new	StackBlitz browser-based AI assistant for scaffolding full-stack web applications with integrated deployment	platform	https://bolt.new	2026-01-20 17:44:56.038	2026-01-20 17:44:56.038	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvwimg00002mtusqfgwvj7	Pcloudy	AI-powered testing platform with multi-agent ecosystem automating QA lifecycle across devices	platform	https://www.pcloudy.com	2026-01-20 17:44:57.917	2026-01-20 17:44:57.917	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvwlqx00004ytuxk4yr1rt	GitHub Copilot	Industry-standard AI code assistant with agent mode for complex tasks, PR creation from issues, and AI-powered code review	tool	https://github.com/features/copilot	2026-01-20 17:45:01.976	2026-01-20 17:45:01.976	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvwpvn000075tui64fho5a	Arize Phoenix	Open-source AI observability with embedded clustering and drift detection for LLM monitoring	platform	https://arize.com	2026-01-20 17:45:07.33	2026-01-20 17:45:07.33	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvx2fr0000cktuml92n8ib	TestSigma	NLP-based test automation converting plain English test steps into executable API tests	tool	https://testsigma.com	2026-01-20 17:45:23.606	2026-01-20 17:45:23.606	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvx83a0000f6tup5y0l8bt	v0	Vercel full-stack application builder with agentic capabilities producing production-grade Next.js code	platform	https://v0.dev	2026-01-20 17:45:30.933	2026-01-20 17:45:30.933	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvxe2n0000hdtuxkfbzh28	Cline	Open-source autonomous coding assistant for VS Code with Plan/Act modes for multi-file project modifications	tool	https://cline.bot	2026-01-20 17:45:38.686	2026-01-20 17:45:38.686	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvxgvf0000jztu3jhaa7au	Langfuse	Self-hosted LLM observability with trace viewing, prompt versioning, and cost tracking	platform	https://langfuse.com	2026-01-20 17:45:42.315	2026-01-20 17:45:42.315	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvxsc20000ontu8x8tog9s	Tricentis	Fully AI-driven codeless test automation built for massive enterprise scale with SAP support	platform	https://www.tricentis.com	2026-01-20 17:45:57.169	2026-01-20 17:45:57.169	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvy0ba0000r1turm82anmm	Lovable	AI app builder generating production-ready TypeScript and React applications from plain English prompts	platform	https://lovable.dev	2026-01-20 17:46:07.509	2026-01-20 17:46:07.509	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvy6vu0000tytu5gcsghjw	Aider	Terminal-based AI pair programming tool with 2M token context window, CLI-first git-native agent for multi-file refactoring	tool	https://aider.chat	2026-01-20 17:46:16.025	2026-01-20 17:46:16.025	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvy8zg0000w6tux0avedit	Dash0	OpenTelemetry-native observability with Agent0 specialized AI agents for engineers	platform	https://www.dash0.com	2026-01-20 17:46:18.747	2026-01-20 17:46:18.747	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvyfa000000dtu0g0dqix0	BrowserStack	Cloud-based testing platform with AI-powered testing across real devices and browsers	platform	https://www.browserstack.com	2026-01-20 17:46:26.904	2026-01-20 17:46:26.904	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvynm100003ptu15skec87	Replit	Browser-based IDE with AI Agent for cross-platform collaborative coding and app generation from prompts	platform	https://replit.com	2026-01-20 17:46:37.704	2026-01-20 17:46:37.704	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvywoj00006mtupdhf21dt	Tabnine	Privacy-first AI code assistant supporting 80+ languages with cloud and self-hosted deployment options for enterprises	tool	https://tabnine.com	2026-01-20 17:46:49.458	2026-01-20 17:46:49.458	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
cmkmvz6jg00009itu8iepa8v4	Grafana Cloud	Observability platform with built-in AI SRE agent for root cause analysis	platform	https://grafana.com	2026-01-20 17:47:02.235	2026-01-20 17:47:02.235	cmkmuy06l0000potui26vfjjd	\N	\N	\N	\N	\N	f	\N	\N	cmkmv1mj600007ftua90zopym
\.


--
-- Data for Name: extractions; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.extractions (id, "schemaType", data, "rawQuotes", status, confidence, error, "extractedAt", "expiresAt", "entityId", "sourceId", "screenshotId", "assertionIds") FROM stdin;
\.


--
-- Data for Name: raw_discoveries; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.raw_discoveries (id, "sourceId", "mentionedName", "briefDescription", "discoveryUrl", "contextSnippet", "extractedLinks", "releaseVersion", "releaseDate", keywords, "discoveredAt", "crawlSessionId", processed, "matchedEntityId", "createdEntityId", "noveltyScore", "relevanceScore") FROM stdin;
\.


--
-- Data for Name: reasoning; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.reasoning (id, content, "createdAt", "updatedAt", "assertionId") FROM stdin;
\.


--
-- Data for Name: research_domains; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.research_domains (id, name, description, "entityTypes", "inclusionCriteria", "exclusionCriteria", "searchHints", "knownLeaders", "relevantTopics", "evaluationDimensions", "lastDiscoveryAt", "entityCount", "createdAt", "updatedAt", "createdBy") FROM stdin;
cmkmv1mj600007ftua90zopym	Agentic-SDLC	AI-focused tools and platforms that promise to disrupt, replace, or enhance traditional software development tools across the entire SDLC	{tool,platform}	Tools and platforms using AI/ML/LLM to automate, augment, or reimagine any SDLC phase: coding, testing, CI/CD, deployment, monitoring, documentation, project management	Traditional tools without AI capabilities, pure infrastructure/DevOps tools that do not leverage AI, general-purpose AI chatbots not specifically focused on software development	Focus on tools with generative AI, code completion, AI agents, autonomous coding, AI-assisted testing, intelligent deployment, AI documentation generators	{Cursor,Windsurf,Cline,Aider}	{"AI code generation","AI code completion","agentic coding","AI testing tools","AI CI/CD","AI deployment","AI documentation","AI code review","LLM for developers","autonomous coding agents","AI pair programming","AI software engineering"}	\N	\N	0	2026-01-20 17:20:56.657	2026-01-20 17:20:56.657	\N
\.


--
-- Data for Name: research_logs; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.research_logs (id, action, details, "agentId", "createdAt") FROM stdin;
cmkmuy09p0001potut82egdsq	project_created	{"name": "Agentic SDLC Research", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:18:07.837
cmkmv1ml000017ftuxnqy17ni	domain_created	{"name": "Agentic-SDLC", "domainId": "cmkmv1mj600007ftua90zopym"}	\N	2026-01-20 17:20:56.724
cmkmvucpz000174tu6irkwf2r	entity_created	{"name": "Datadog", "entityId": "cmkmvucn6000074tu9jjh9wea", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:43:16.966
cmkmvuy4v0001cptuj0kbfmxm	entity_created	{"name": "Devin", "entityId": "cmkmvuxyr0000cptupdif066l", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:43:44.719
cmkmvuyyx0001dwtuxa0wdch3	entity_created	{"name": "Cursor", "entityId": "cmkmvuyt40000dwtu0oa0t8lx", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:43:45.801
cmkmvv4ic0001grtujavt4gdv	entity_created	{"name": "Mabl", "entityId": "cmkmvv4fd0000grtuuxf08eca", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:43:52.98
cmkmvv5lr0001ictuinvi0d0f	entity_created	{"name": "Dynatrace", "entityId": "cmkmvv5g00000ictuaepu82rp", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:43:54.399
cmkmvvp820001p7tulkyjywbd	entity_created	{"name": "OpenHands", "entityId": "cmkmvvp2d0000p7tun51tcoqp", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:44:19.826
cmkmvvrub0001qrtuqab0jh2p	entity_created	{"name": "Windsurf", "entityId": "cmkmvvrol0000qrtut1zjo7fb", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:44:23.218
cmkmvvu9w0001shtuo9k00lyu	entity_created	{"name": "Virtuoso QA", "entityId": "cmkmvvu2p0000shtueglgn100", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:44:26.372
cmkmvvx1l0001vhtu0ygujy4u	entity_created	{"name": "Braintrust", "entityId": "cmkmvvwym0000vhtuhkactypx", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:44:29.961
cmkmvwhb2000114tuw0hymzku	entity_created	{"name": "Bolt.new", "entityId": "cmkmvwh63000014tuu8d8p7tg", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:44:56.222
cmkmvwiph00012mtuupi0cz3s	entity_created	{"name": "Pcloudy", "entityId": "cmkmvwimg00002mtusqfgwvj7", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:44:58.037
cmkmvwlti00014ytutw4wvr9n	entity_created	{"name": "GitHub Copilot", "entityId": "cmkmvwlqx00004ytuxk4yr1rt", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:45:02.07
cmkmvwq15000175tuhcep6ph2	entity_created	{"name": "Arize Phoenix", "entityId": "cmkmvwpvn000075tui64fho5a", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:45:07.529
cmkmvx2kn0001cktuguivccxp	entity_created	{"name": "TestSigma", "entityId": "cmkmvx2fr0000cktuml92n8ib", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:45:23.783
cmkmvx8830001f6tuqrosy6q5	entity_created	{"name": "v0", "entityId": "cmkmvx83a0000f6tup5y0l8bt", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:45:31.107
cmkmvxe6t0001hdtur7zncskt	entity_created	{"name": "Cline", "entityId": "cmkmvxe2n0000hdtuxkfbzh28", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:45:38.837
cmkmvxgzt0001jztu52bxj0tl	entity_created	{"name": "Langfuse", "entityId": "cmkmvxgvf0000jztu3jhaa7au", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:45:42.473
cmkmvxsh60001ontuty0bgw1n	entity_created	{"name": "Tricentis", "entityId": "cmkmvxsc20000ontu8x8tog9s", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:45:57.354
cmkmvy0f40001r1tuxq1grtg9	entity_created	{"name": "Lovable", "entityId": "cmkmvy0ba0000r1turm82anmm", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:46:07.648
cmkmvy7090001tytu319m04jm	entity_created	{"name": "Aider", "entityId": "cmkmvy6vu0000tytu5gcsghjw", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:46:16.185
cmkmvy92c0001w6tupcak9jjz	entity_created	{"name": "Dash0", "entityId": "cmkmvy8zg0000w6tux0avedit", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:46:18.852
cmkmvyfe500010dtupnsqszlk	entity_created	{"name": "BrowserStack", "entityId": "cmkmvyfa000000dtu0g0dqix0", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:46:27.053
cmkmvynp700013ptu59y75tsm	entity_created	{"name": "Replit", "entityId": "cmkmvynm100003ptu15skec87", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:46:37.819
cmkmvywsi00016mtul3hhjh3d	entity_created	{"name": "Tabnine", "entityId": "cmkmvywoj00006mtupdhf21dt", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:46:49.602
cmkmvz6qd00019itughf9633z	entity_created	{"name": "Grafana Cloud", "entityId": "cmkmvz6jg00009itu8iepa8v4", "projectId": "cmkmuy06l0000potui26vfjjd"}	\N	2026-01-20 17:47:02.485
\.


--
-- Data for Name: research_projects; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.research_projects (id, name, description, "searchQuery", workflow, "createdAt", "updatedAt") FROM stdin;
cmkmuy06l0000potui26vfjjd	Agentic SDLC Research	AI-focused tools that promise to disrupt, replace, or enhance traditional software development tools across the entire SDLC	\N	DISCOVERY	2026-01-20 17:18:07.724	2026-01-20 17:18:07.724
\.


--
-- Data for Name: research_sessions; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.research_sessions (id, "entityId", "projectId", "researcherName", status, "createdAt", "startedAt", "completedAt", "pausedAt", categories, mode, config, "overallProgress", "totalTasks", "completedTasks", "failedTasks", "totalAssertions", "totalScreenshots", "totalExtractions") FROM stdin;
\.


--
-- Data for Name: research_tasks; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.research_tasks (id, "sessionId", category, status, "agentId", "startedAt", "completedAt", error, progress, results) FROM stdin;
\.


--
-- Data for Name: screenshots; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.screenshots (id, "filePath", url, "fullPage", width, height, "capturedAt") FROM stdin;
\.


--
-- Data for Name: sources; Type: TABLE DATA; Schema: public; Owner: researcher
--

COPY public.sources (id, url, title, description, "sourceType", status, "createdAt", "updatedAt", "validatedAt", "validatedBy", "contentHash", "isAccessible", "lastFetchedAt", "lastStatusCode") FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: assertion_sources assertion_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.assertion_sources
    ADD CONSTRAINT assertion_sources_pkey PRIMARY KEY (id);


--
-- Name: assertions assertions_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.assertions
    ADD CONSTRAINT assertions_pkey PRIMARY KEY (id);


--
-- Name: discovery_crawls discovery_crawls_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.discovery_crawls
    ADD CONSTRAINT discovery_crawls_pkey PRIMARY KEY (id);


--
-- Name: discovery_sources discovery_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.discovery_sources
    ADD CONSTRAINT discovery_sources_pkey PRIMARY KEY (id);


--
-- Name: discovery_trends discovery_trends_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.discovery_trends
    ADD CONSTRAINT discovery_trends_pkey PRIMARY KEY (id);


--
-- Name: entities entities_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.entities
    ADD CONSTRAINT entities_pkey PRIMARY KEY (id);


--
-- Name: extractions extractions_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.extractions
    ADD CONSTRAINT extractions_pkey PRIMARY KEY (id);


--
-- Name: raw_discoveries raw_discoveries_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.raw_discoveries
    ADD CONSTRAINT raw_discoveries_pkey PRIMARY KEY (id);


--
-- Name: reasoning reasoning_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.reasoning
    ADD CONSTRAINT reasoning_pkey PRIMARY KEY (id);


--
-- Name: research_domains research_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.research_domains
    ADD CONSTRAINT research_domains_pkey PRIMARY KEY (id);


--
-- Name: research_logs research_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.research_logs
    ADD CONSTRAINT research_logs_pkey PRIMARY KEY (id);


--
-- Name: research_projects research_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.research_projects
    ADD CONSTRAINT research_projects_pkey PRIMARY KEY (id);


--
-- Name: research_sessions research_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.research_sessions
    ADD CONSTRAINT research_sessions_pkey PRIMARY KEY (id);


--
-- Name: research_tasks research_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.research_tasks
    ADD CONSTRAINT research_tasks_pkey PRIMARY KEY (id);


--
-- Name: screenshots screenshots_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.screenshots
    ADD CONSTRAINT screenshots_pkey PRIMARY KEY (id);


--
-- Name: sources sources_pkey; Type: CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_pkey PRIMARY KEY (id);


--
-- Name: assertion_sources_addedBy_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "assertion_sources_addedBy_idx" ON public.assertion_sources USING btree ("addedBy");


--
-- Name: assertion_sources_assertionId_sourceId_key; Type: INDEX; Schema: public; Owner: researcher
--

CREATE UNIQUE INDEX "assertion_sources_assertionId_sourceId_key" ON public.assertion_sources USING btree ("assertionId", "sourceId");


--
-- Name: assertion_sources_relevanceGrade_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "assertion_sources_relevanceGrade_idx" ON public.assertion_sources USING btree ("relevanceGrade");


--
-- Name: assertions_citedInConclusion_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "assertions_citedInConclusion_idx" ON public.assertions USING btree ("citedInConclusion");


--
-- Name: assertions_criticality_status_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX assertions_criticality_status_idx ON public.assertions USING btree (criticality, status);


--
-- Name: assertions_discoverySourceId_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "assertions_discoverySourceId_idx" ON public.assertions USING btree ("discoverySourceId");


--
-- Name: discovery_crawls_startedAt_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "discovery_crawls_startedAt_idx" ON public.discovery_crawls USING btree ("startedAt");


--
-- Name: discovery_crawls_status_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX discovery_crawls_status_idx ON public.discovery_crawls USING btree (status);


--
-- Name: discovery_sources_isActive_priority_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "discovery_sources_isActive_priority_idx" ON public.discovery_sources USING btree ("isActive", priority);


--
-- Name: discovery_sources_lastCrawledAt_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "discovery_sources_lastCrawledAt_idx" ON public.discovery_sources USING btree ("lastCrawledAt");


--
-- Name: discovery_sources_name_key; Type: INDEX; Schema: public; Owner: researcher
--

CREATE UNIQUE INDEX discovery_sources_name_key ON public.discovery_sources USING btree (name);


--
-- Name: discovery_sources_sourceType_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "discovery_sources_sourceType_idx" ON public.discovery_sources USING btree ("sourceType");


--
-- Name: discovery_trends_category_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX discovery_trends_category_idx ON public.discovery_trends USING btree (category);


--
-- Name: discovery_trends_trendScore_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "discovery_trends_trendScore_idx" ON public.discovery_trends USING btree ("trendScore");


--
-- Name: entities_domainId_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "entities_domainId_idx" ON public.entities USING btree ("domainId");


--
-- Name: entities_projectId_name_key; Type: INDEX; Schema: public; Owner: researcher
--

CREATE UNIQUE INDEX "entities_projectId_name_key" ON public.entities USING btree ("projectId", name);


--
-- Name: extractions_entityId_schemaType_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "extractions_entityId_schemaType_idx" ON public.extractions USING btree ("entityId", "schemaType");


--
-- Name: extractions_status_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX extractions_status_idx ON public.extractions USING btree (status);


--
-- Name: raw_discoveries_mentionedName_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "raw_discoveries_mentionedName_idx" ON public.raw_discoveries USING btree ("mentionedName");


--
-- Name: raw_discoveries_processed_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX raw_discoveries_processed_idx ON public.raw_discoveries USING btree (processed);


--
-- Name: raw_discoveries_sourceId_discoveredAt_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "raw_discoveries_sourceId_discoveredAt_idx" ON public.raw_discoveries USING btree ("sourceId", "discoveredAt");


--
-- Name: research_domains_name_key; Type: INDEX; Schema: public; Owner: researcher
--

CREATE UNIQUE INDEX research_domains_name_key ON public.research_domains USING btree (name);


--
-- Name: research_sessions_entityId_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "research_sessions_entityId_idx" ON public.research_sessions USING btree ("entityId");


--
-- Name: research_sessions_projectId_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "research_sessions_projectId_idx" ON public.research_sessions USING btree ("projectId");


--
-- Name: research_sessions_status_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX research_sessions_status_idx ON public.research_sessions USING btree (status);


--
-- Name: research_tasks_category_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX research_tasks_category_idx ON public.research_tasks USING btree (category);


--
-- Name: research_tasks_sessionId_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX "research_tasks_sessionId_idx" ON public.research_tasks USING btree ("sessionId");


--
-- Name: research_tasks_status_idx; Type: INDEX; Schema: public; Owner: researcher
--

CREATE INDEX research_tasks_status_idx ON public.research_tasks USING btree (status);


--
-- Name: sources_url_key; Type: INDEX; Schema: public; Owner: researcher
--

CREATE UNIQUE INDEX sources_url_key ON public.sources USING btree (url);


--
-- Name: assertion_sources assertion_sources_assertionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.assertion_sources
    ADD CONSTRAINT "assertion_sources_assertionId_fkey" FOREIGN KEY ("assertionId") REFERENCES public.assertions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assertion_sources assertion_sources_sourceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.assertion_sources
    ADD CONSTRAINT "assertion_sources_sourceId_fkey" FOREIGN KEY ("sourceId") REFERENCES public.sources(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assertions assertions_entityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.assertions
    ADD CONSTRAINT "assertions_entityId_fkey" FOREIGN KEY ("entityId") REFERENCES public.entities(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: entities entities_domainId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.entities
    ADD CONSTRAINT "entities_domainId_fkey" FOREIGN KEY ("domainId") REFERENCES public.research_domains(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: entities entities_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.entities
    ADD CONSTRAINT "entities_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.research_projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: extractions extractions_entityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.extractions
    ADD CONSTRAINT "extractions_entityId_fkey" FOREIGN KEY ("entityId") REFERENCES public.entities(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: extractions extractions_screenshotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.extractions
    ADD CONSTRAINT "extractions_screenshotId_fkey" FOREIGN KEY ("screenshotId") REFERENCES public.screenshots(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: extractions extractions_sourceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.extractions
    ADD CONSTRAINT "extractions_sourceId_fkey" FOREIGN KEY ("sourceId") REFERENCES public.sources(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: raw_discoveries raw_discoveries_sourceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.raw_discoveries
    ADD CONSTRAINT "raw_discoveries_sourceId_fkey" FOREIGN KEY ("sourceId") REFERENCES public.discovery_sources(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reasoning reasoning_assertionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.reasoning
    ADD CONSTRAINT "reasoning_assertionId_fkey" FOREIGN KEY ("assertionId") REFERENCES public.assertions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: research_sessions research_sessions_entityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.research_sessions
    ADD CONSTRAINT "research_sessions_entityId_fkey" FOREIGN KEY ("entityId") REFERENCES public.entities(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: research_tasks research_tasks_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: researcher
--

ALTER TABLE ONLY public.research_tasks
    ADD CONSTRAINT "research_tasks_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.research_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: researcher
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict cURIc3vrFNc9uLXGoBKjmqna44gtwgWUGrMExAx8CSNhcPlfxhPT9hIprRgcys0

